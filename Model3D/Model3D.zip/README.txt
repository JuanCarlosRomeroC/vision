Barak Ugav 	318336229
Yishai Gronich 	208989186

Setting Up the Environment
==========================

1. Download Anaconda for Python 3.5 from:
	https://www.continuum.io/downloads
2. Enter CMD with admin permissions and write:
	conda install -c https://conda.anaconda.org/menpo opencv3
3. Make sure that the active version of Python on the computer is the Anaconda for Python 3.
4. Download and install the library PyMsgBox. The library can be downloaded from here:
	https://pypi.python.org/pypi/PyMsgBox
	Download the ZIP file, unzip it, navigate to the unzipped directory, and then run:
		python setup.py install
5. Program usage: see the INSTRUCTIONS file.
